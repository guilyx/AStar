package minimalpkg

func SomeTestFunc() {}
