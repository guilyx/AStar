package version

func Value() string {
	return "v0.3.1"
}
